# اترك أثر — المشروع الكامل (مدمج)
1. Supabase > SQL Editor: شغّل supabase/00-RUN-ALL-IN-ORDER.sql مرة واحدة (فيه كل المراحل بالترتيب).
2. Storage: أنشئ bucket اسمه videos (Public).
3. التطبيق الرئيسي: انسخ .env.example إلى .env.local، ثم npm install && npm run dev.
4. لوحة Backstage: داخل admin/ بمتغيراتها الخاصة (انظر admin/.env.example) ثم npm install && npm run dev (منفذ 3001).
