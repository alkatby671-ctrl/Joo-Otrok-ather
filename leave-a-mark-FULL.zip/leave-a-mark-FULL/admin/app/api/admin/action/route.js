import { NextResponse } from "next/server";
import { verify } from "../../../../lib/admin-session";
import { createClient } from "@supabase/supabase-js";

export async function POST(req) {
  const session = verify(req.cookies.get("lam_admin")?.value);

  if (!session) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }

  const { kind, id, details } = await req.json();

  const admin = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.SUPABASE_SERVICE_ROLE_KEY,
    { auth: { persistSession: false } }
  );

  let result;

  if (kind === "approve_video") {
    result = await admin
      .from("videos")
      .update({ status: "approved" })
      .eq("id", id);
  } else if (kind === "reject_video") {
    result = await admin
      .from("videos")
      .update({ status: "rejected" })
      .eq("id", id);
  } else if (kind === "approve_purchase") {
    result = await admin.rpc("approve_coin_purchase", {
      p_purchase_id: id
    });
  } else if (kind === "resolve_payout") {
    const decision = details?.decision;

    if (decision !== "approved" && decision !== "rejected") {
      return NextResponse.json(
        { error: "قرار غير صحيح" },
        { status: 400 }
      );
    }

    result = await admin.rpc("admin_resolve_payout", {
      p_id: id,
      p_decision: decision
    });
  } else if (kind === "issue_bonus_coins") {
    result = await admin.rpc("admin_issue_bonus_coins", {
      p_user: id,
      p_coins: details?.coins
    });
  } else {
    return NextResponse.json({ error: "unknown action" }, { status: 400 });
  }

  if (result?.error) {
    return NextResponse.json(
      { error: result.error.message || "فشل تنفيذ الإجراء" },
      { status: 400 }
    );
  }

  const audit = await admin.from("admin_audit").insert({
    actor: "admin",
    action: kind,
    target: id,
    details: details || {}
  });

  if (audit?.error) {
    return NextResponse.json(
      { error: audit.error.message || "فشل تسجيل الإجراء" },
      { status: 400 }
    );
  }

  return NextResponse.json({ ok: true });
}
