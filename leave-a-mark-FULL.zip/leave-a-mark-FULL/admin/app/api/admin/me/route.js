import { NextResponse } from "next/server";
import { verify } from "../../../../lib/admin-session";

export async function GET(req) {
  const session = verify(req.cookies.get("lam_admin")?.value);
  if (!session) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
  return NextResponse.json({ ok: true, role: session.role });
}
