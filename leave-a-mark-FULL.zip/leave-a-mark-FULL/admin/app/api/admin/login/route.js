import { NextResponse } from "next/server";
import crypto from "crypto";
import { sign } from "../../../../lib/admin-session";
import { checkRateLimit } from "../../../../lib/rate-limit";

export async function POST(req) {
  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    req.headers.get("x-real-ip") ||
    "unknown";

  const limit = checkRateLimit(ip);
  if (!limit.allowed) {
    return NextResponse.json(
      { error: "تم تجاوز عدد المحاولات. حاول بعد 15 دقيقة." },
      { status: 429 }
    );
  }

  const { password } = await req.json();
  const expected = Buffer.from(process.env.ADMIN_PASSWORD || "");
  const received = Buffer.from(String(password || ""));

  const valid =
    expected.length === received.length &&
    crypto.timingSafeEqual(expected, received);

  if (!valid) {
    return NextResponse.json({ error: "كلمة مرور خاطئة" }, { status: 401 });
  }

  const token = sign({
    role: "admin",
    exp: Date.now() + 1000 * 60 * 60 * 8
  });

  const res = NextResponse.json({ ok: true });
  res.cookies.set("lam_admin", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    path: "/",
    maxAge: 60 * 60 * 8
  });

  return res;
}
