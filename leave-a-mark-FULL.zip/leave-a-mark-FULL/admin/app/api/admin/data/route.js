import { NextResponse } from "next/server";
import { verify } from "../../../../lib/admin-session";
import { createClient } from "@supabase/supabase-js";

export async function GET(req) {
  const session = verify(req.cookies.get("lam_admin")?.value);
  if (!session) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }

  const admin = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.SUPABASE_SERVICE_ROLE_KEY,
    { auth: { persistSession: false } }
  );

  const videos = await admin
    .from("videos")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(50);

  const purchases = await admin
    .from("coin_purchases")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(50);

  const payouts = await admin
    .from("payout_requests")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(50);

  return NextResponse.json({
    videos: videos.data || [],
    purchases: purchases.data || [],
    payouts: payouts.data || []
  });
}
