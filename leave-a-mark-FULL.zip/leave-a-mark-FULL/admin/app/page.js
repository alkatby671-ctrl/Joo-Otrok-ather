"use client";
import { useEffect, useState } from "react";

export default function Backstage() {
  const [password, setPassword] = useState("");
  const [authed, setAuthed] = useState(false);
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState({
    videos: [],
    purchases: [],
    payouts: []
  });

  async function load() {
    const res = await fetch("/api/admin/data");
    if (res.ok) {
      setData(await res.json());
      setAuthed(true);
    } else {
      setAuthed(false);
    }
    setLoading(false);
  }

  useEffect(() => {
    (async () => {
      const res = await fetch("/api/admin/me");
      if (res.ok) {
        await load();
      } else {
        setLoading(false);
      }
    })();
  }, []);

  async function login() {
    const res = await fetch("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password })
    });

    if (res.ok) {
      await load();
    } else {
      const data = await res.json();
      alert(data.error || "فشل الدخول");
    }
  }

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    setAuthed(false);
  }

  async function act(kind, id, details = {}) {
    const res = await fetch("/api/admin/action", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind, id, details })
    });

    if (!res.ok) {
      const data = await res.json();
      alert(data.error || "فشل الإجراء");
    }

    await load();
  }

  if (loading) {
    return <main style={{ padding: 40 }}>جارٍ التحقق...</main>;
  }

  if (!authed) {
    return (
      <main style={{ padding: 40, maxWidth: 420, margin: "auto" }}>
        <div className="card">
          <h1>Backstage</h1>
          <input
            className="input"
            type="password"
            placeholder="كلمة مرور المشرف"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <button className="btn" onClick={login}>
            دخول
          </button>
        </div>
      </main>
    );
  }

  return (
    <main style={{ padding: 24 }}>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <h1>لوحة Backstage</h1>
        <button onClick={logout}>خروج</button>
      </div>

      <h2>الفيديوهات</h2>
      <table border="1" cellPadding="8" style={{ width: "100%", borderCollapse: "collapse" }}>
        <tbody>
          {data.videos.map((v) => (
            <tr key={v.id}>
              <td>{v.title}</td>
              <td>{v.status}</td>
              <td>
                <button onClick={() => act("approve_video", v.id)}>اعتماد</button>{" "}
                <button onClick={() => act("reject_video", v.id)}>رفض</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>طلبات الشحن</h2>
      <table border="1" cellPadding="8" style={{ width: "100%", borderCollapse: "collapse" }}>
        <tbody>
          {data.purchases.map((c) => (
            <tr key={c.id}>
              <td>{c.user_id}</td>
              <td>{c.coins}</td>
              <td>{c.amount_egp}</td>
              <td>{c.status}</td>
              <td>
                <button onClick={() => act("approve_purchase", c.id)}>اعتماد</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>طلبات السحب</h2>
      <table border="1" cellPadding="8" style={{ width: "100%", borderCollapse: "collapse" }}>
        <tbody>
          {data.payouts.map((w) => (
            <tr key={w.id}>
              <td>{w.user_id}</td>
              <td>{w.amount_egp}</td>
              <td>{w.phone}</td>
              <td>{w.status}</td>
              <td>
                <button
                  onClick={() =>
                    act("resolve_payout", w.id, { decision: "approved" })
                  }
                >
                  اعتماد
                </button>{" "}
                <button
                  onClick={() =>
                    act("resolve_payout", w.id, { decision: "rejected" })
                  }
                >
                  رفض واسترجاع
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  );
}
