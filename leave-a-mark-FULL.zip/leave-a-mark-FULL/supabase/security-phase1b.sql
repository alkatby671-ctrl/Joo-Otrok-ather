-- ===== security-phase1b.sql =====
-- 1) منع تعديل الأرصدة من العميل
revoke update on table public.profiles from authenticated, anon;
grant update (display_name, avatar_url, username) on table public.profiles to authenticated;

-- 2) السحب فقط عبر request_payout
drop policy if exists "create payout" on public.payout_requests;
revoke insert on table public.payout_requests from authenticated, anon;

-- 3) طلبات الشحن: insert كـ pending فقط، ومنع update/delete
drop policy if exists "create purchase" on public.coin_purchases;
create policy "create pending purchase" on public.coin_purchases
for insert to authenticated
with check (auth.uid() = user_id and status = 'pending');

revoke update on table public.coin_purchases from authenticated, anon;
revoke delete on table public.coin_purchases from authenticated, anon;

-- 4) دالة قرار السحب: اعتماد أو رفض مع استرجاع الأرباح
create or replace function public.admin_resolve_payout(p_id uuid, p_decision text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid;
  v_amount numeric;
  v_status text;
begin
  if p_decision not in ('approved','rejected') then
    raise exception 'قرار غير صحيح';
  end if;

  select user_id, amount_egp, status
  into v_user, v_amount, v_status
  from public.payout_requests
  where id = p_id
  for update;

  if v_user is null then
    raise exception 'طلب السحب غير موجود';
  end if;

  if v_status <> 'pending' then
    raise exception 'تم البت في هذا الطلب مسبقًا';
  end if;

  update public.payout_requests
  set status = p_decision
  where id = p_id;

  if p_decision = 'rejected' then
    update public.profiles
    set earnings = earnings + v_amount
    where id = v_user;
  end if;
end;
$$;

revoke execute on function public.admin_resolve_payout(uuid, text) from anon, authenticated, public;

-- حذف دالة الاسترجاع القديمة
drop function if exists public.refund_payout(uuid);

-- 5) إصدار عملات ترويجية: إضافة على الرصيد بحد أقصى 100000 للعملية
create or replace function public.admin_issue_bonus_coins(p_user uuid, p_coins numeric)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if p_coins is null or p_coins <= 0 or p_coins > 100000 then
    raise exception 'عدد العملات غير صحيح أو يتجاوز الحد الأقصى';
  end if;

  update public.profiles
  set bonus_coins = coalesce(bonus_coins,0) + p_coins
  where id = p_user;

  if not found then
    raise exception 'المستخدم غير موجود';
  end if;
end;
$$;

revoke execute on function public.admin_issue_bonus_coins(uuid, numeric) from anon, authenticated, public;

-- 6) الهدايا تستهلك سعر الهدية من جدول gifts وتتجاهل p_coins
create or replace function public.send_economy_gift(
  p_stream_id uuid,
  p_gift_slug text,
  p_coins numeric
)
returns json
language plpgsql
security definer
set search_path = public
as $$
declare
  v_sender uuid := auth.uid();
  v_receiver uuid;
  v_gift public.gifts%rowtype;
  v_paid numeric;
  v_bonus numeric;
  v_total numeric;
  v_earn numeric;
begin
  if v_sender is null then
    raise exception 'يجب تسجيل الدخول';
  end if;

  select user_id into v_receiver
  from public.streams
  where id = p_stream_id and status = 'live';

  if v_receiver is null then
    raise exception 'البث غير موجود أو انتهى';
  end if;

  if v_receiver = v_sender then
    raise exception 'لا يمكنك إرسال هدية لنفسك';
  end if;

  select * into v_gift
  from public.gifts
  where slug = p_gift_slug and active = true;

  if v_gift is null then
    raise exception 'الهدية غير متاحة';
  end if;

  v_total := v_gift.coin_price;

  select paid_coins, bonus_coins
  into v_paid, v_bonus
  from public.profiles
  where id = v_sender
  for update;

  if coalesce(v_paid,0) + coalesce(v_bonus,0) < v_total then
    raise exception 'رصيد العملات غير كافٍ';
  end if;

  v_paid := least(coalesce(v_paid,0), v_total);
  v_bonus := v_total - v_paid;
  v_earn := v_paid * v_gift.creator_ratio;

  update public.profiles
  set paid_coins = paid_coins - v_paid,
      bonus_coins = bonus_coins - v_bonus
  where id = v_sender;

  update public.profiles
  set earnings = earnings + v_earn
  where id = v_receiver;

  insert into public.gift_events(
    stream_id, sender_id, receiver_id, gift_id,
    coins_spent, paid_coins_used, bonus_coins_used, earnings_added
  ) values (
    p_stream_id, v_sender, v_receiver, v_gift.id,
    v_total, v_paid, v_bonus, v_earn
  );

  return json_build_object(
    'ok', true,
    'coins_spent', v_total,
    'paid_coins_used', v_paid,
    'bonus_coins_used', v_bonus,
    'creator_earnings', v_earn
  );
end;
$$;

revoke execute on function public.send_economy_gift(uuid, text, numeric) from anon;
grant execute on function public.send_economy_gift(uuid, text, numeric) to authenticated;

-- 7) قراءة أحداث الهدايا للمرسل أو المستقبل فقط
drop policy if exists "read gift events" on public.gift_events;
create policy "read own gift events" on public.gift_events
for select to authenticated
using (auth.uid() = sender_id or auth.uid() = receiver_id);

-- 8) Storage: رفع داخل مجلد المستخدم فقط، وقراءة عامة
drop policy if exists "videos public read" on storage.objects;
drop policy if exists "videos user upload" on storage.objects;

create policy "videos public read"
on storage.objects for select
using (bucket_id = 'videos');

create policy "videos user upload"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'videos'
  and (storage.foldername(name))[1] = auth.uid()::text
);
