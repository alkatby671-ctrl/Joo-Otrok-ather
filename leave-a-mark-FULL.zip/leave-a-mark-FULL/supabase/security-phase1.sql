-- المرحلة 1: إغلاق الثغرات المالية

-- منع المستخدمين من تنفيذ دوال الاعتماد
revoke execute on function public.approve_coin_purchase(uuid) from authenticated;
revoke execute on function public.approve_coin_purchase(uuid) from anon;
revoke execute on function public.approve_coin_purchase(uuid) from public;

-- السحب الحقيقي: يخصم الأرباح ويمنع السحب أكبر من الرصيد
create or replace function public.request_payout(p_amount_egp numeric,p_phone text)
returns uuid language plpgsql security definer as $$
declare v_user uuid:=auth.uid(); v_balance numeric; v_id uuid;
begin
 if v_user is null then raise exception 'يجب تسجيل الدخول'; end if;
 if p_amount_egp is null or p_amount_egp<50 then raise exception 'الحد الأدنى للسحب 50 جنيه'; end if;
 if p_phone is null or length(p_phone)<10 then raise exception 'رقم فودافون كاش غير صحيح'; end if;

 select earnings into v_balance from profiles where id=v_user for update;
 if v_balance is null or v_balance<p_amount_egp then raise exception 'رصيد الأرباح غير كافٍ'; end if;

 update profiles set earnings=earnings-p_amount_egp where id=v_user;

 insert into payout_requests(user_id,amount_egp,phone,status)
 values(v_user,p_amount_egp,p_phone,'pending')
 returning id into v_id;

 return v_id;
end; $$;

revoke execute on function public.request_payout(numeric,text) from anon;
grant execute on function public.request_payout(numeric,text) to authenticated;

-- سياسات صارمة
alter table profiles enable row level security;
drop policy if exists "update own profile" on profiles;
create policy "user updates limited profile" on profiles for update using (auth.uid()=id)
with check (auth.uid()=id);

-- منع المستخدم من قراءة طلبات سحب الآخرين
drop policy if exists "read own payout" on payout_requests;
create policy "read own payout" on payout_requests for select using (auth.uid()=user_id);
drop policy if exists "create payout" on payout_requests;
create policy "create payout" on payout_requests for insert with check (auth.uid()=user_id);

-- منع المستخدم من قراءة طلبات شحن الآخرين
drop policy if exists "read own purchase" on coin_purchases;
create policy "read own purchase" on coin_purchases for select using (auth.uid()=user_id);
drop policy if exists "create purchase" on coin_purchases;
create policy "create purchase" on coin_purchases for insert with check (auth.uid()=user_id);

-- سجل التدقيق متاح للقراءة للـservice_role فقط
drop policy if exists "audit read" on admin_audit;
