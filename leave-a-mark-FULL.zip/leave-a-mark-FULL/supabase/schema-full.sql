-- اترك أثر — قاعدة البيانات الكاملة
create table if not exists profiles(
 id uuid primary key references auth.users on delete cascade,
 username text unique, display_name text, avatar_url text,
 paid_coins numeric default 0, bonus_coins numeric default 0, earnings numeric default 0,
 role text default 'user', created_at timestamptz default now());

create table if not exists videos(
 id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade,
 title text, video_url text, status text default 'pending', views bigint default 0, likes bigint default 0,
 created_at timestamptz default now());

create table if not exists streams(
 id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade,
 title text, status text default 'live', viewers bigint default 0, started_at timestamptz default now());

create table if not exists gifts(
 id uuid primary key default gen_random_uuid(), slug text unique, name_ar text, name_en text,
 coin_price numeric, earnings_value numeric, creator_ratio numeric default .7, emoji text,
 animation text, type text default 'cinematic', kind text default 'epic', active boolean default true,
 model_url text);

create table if not exists gift_events(
 id uuid primary key default gen_random_uuid(), stream_id uuid, sender_id uuid references auth.users on delete set null,
 receiver_id uuid references auth.users on delete set null, gift_id uuid references gifts on delete set null,
 coins_spent numeric, paid_coins_used numeric default 0, bonus_coins_used numeric default 0,
 earnings_added numeric, created_at timestamptz default now());

create table if not exists coin_purchases(
 id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade,
 coins numeric, amount_egp numeric, payment_method text default 'vodafone_cash', payment_ref text,
 status text default 'pending', created_at timestamptz default now());

create table if not exists payout_requests(
 id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade,
 amount_egp numeric, phone text, status text default 'pending', created_at timestamptz default now());

create table if not exists admin_audit(
 id uuid primary key default gen_random_uuid(), actor text, action text, target text,
 details jsonb, created_at timestamptz default now());

insert into gifts(slug,name_ar,name_en,coin_price,earnings_value,creator_ratio,emoji,animation,type,kind,active) values
('fall-01','شهاب 1','Falling 1',100,7.0,0.7,'🌠','fall','cinematic','epic',true),
('fall-02','شهاب 2','Falling 2',200,14.0,0.7,'☄️','fall','cinematic','epic',true),
('fall-03','شهاب 3','Falling 3',300,21.0,0.7,'🌟','fall','cinematic','epic',true),
('fall-04','شهاب 4','Falling 4',400,28.0,0.7,'✨','fall','cinematic','epic',true),
('fall-05','شهاب 5','Falling 5',500,35.0,0.7,'💫','fall','cinematic','epic',true),
('fall-06','شهاب 6','Falling 6',600,42.0,0.7,'🌙','fall','cinematic','epic',true),
('fall-07','شهاب 7','Falling 7',700,49.0,0.7,'🔥','fall','cinematic','epic',true),
('fall-08','شهاب 8','Falling 8',800,56.0,0.7,'⚡','fall','cinematic','epic',true),
('fall-09','شهاب 9','Falling 9',900,63.0,0.7,'💎','fall','cinematic','epic',true),
('fall-10','شهاب 10','Falling 10',1000,70.0,0.7,'👑','fall','cinematic','epic',true),
('fall-11','شهاب 11','Falling 11',1100,77.0,0.7,'🌠','fall','cinematic','epic',true),
('fall-12','شهاب 12','Falling 12',1200,84.0,0.7,'☄️','fall','cinematic','epic',true),
('fall-13','شهاب 13','Falling 13',1300,91.0,0.7,'🌟','fall','cinematic','epic',true),
('fall-14','شهاب 14','Falling 14',1400,98.0,0.7,'✨','fall','cinematic','epic',true),
('fall-15','شهاب 15','Falling 15',1500,105.0,0.7,'💫','fall','cinematic','epic',true),
('fall-16','شهاب 16','Falling 16',1600,112.0,0.7,'🌙','fall','cinematic','epic',true),
('fall-17','شهاب 17','Falling 17',1700,119.0,0.7,'🔥','fall','cinematic','epic',true),
('fall-18','شهاب 18','Falling 18',1800,126.0,0.7,'⚡','fall','cinematic','epic',true),
('fall-19','شهاب 19','Falling 19',1900,133.0,0.7,'💎','fall','cinematic','epic',true),
('fall-20','شهاب 20','Falling 20',2000,140.0,0.7,'👑','fall','cinematic','epic',true),
('fall-21','شهاب 21','Falling 21',2100,147.0,0.7,'🌠','fall','cinematic','epic',true),
('fall-22','شهاب 22','Falling 22',2200,154.0,0.7,'☄️','fall','cinematic','epic',true),
('fall-23','شهاب 23','Falling 23',2300,161.0,0.7,'🌟','fall','cinematic','epic',true),
('fall-24','شهاب 24','Falling 24',2400,168.0,0.7,'✨','fall','cinematic','epic',true),
('fall-25','شهاب 25','Falling 25',2500,175.0,0.7,'💫','fall','cinematic','epic',true),
('fall-26','شهاب 26','Falling 26',2600,182.0,0.7,'🌙','fall','cinematic','epic',true),
('fall-27','شهاب 27','Falling 27',2700,189.0,0.7,'🔥','fall','cinematic','epic',true),
('fall-28','شهاب 28','Falling 28',2800,196.0,0.7,'⚡','fall','cinematic','epic',true),
('fall-29','شهاب 29','Falling 29',2900,203.0,0.7,'💎','fall','cinematic','epic',true),
('fall-30','شهاب 30','Falling 30',3000,210.0,0.7,'👑','fall','cinematic','epic',true),
('fall-31','شهاب 31','Falling 31',3100,217.0,0.7,'🌠','fall','cinematic','epic',true),
('fall-32','شهاب 32','Falling 32',3200,224.0,0.7,'☄️','fall','cinematic','epic',true),
('fall-33','شهاب 33','Falling 33',3300,231.0,0.7,'🌟','fall','cinematic','epic',true),
('fall-34','شهاب 34','Falling 34',3400,238.0,0.7,'✨','fall','cinematic','epic',true),
('fall-35','شهاب 35','Falling 35',3500,245.0,0.7,'💫','fall','cinematic','epic',true),
('fall-36','شهاب 36','Falling 36',3600,252.0,0.7,'🌙','fall','cinematic','epic',true),
('fall-37','شهاب 37','Falling 37',3700,259.0,0.7,'🔥','fall','cinematic','epic',true),
('fall-38','شهاب 38','Falling 38',3800,266.0,0.7,'⚡','fall','cinematic','epic',true),
('fall-39','شهاب 39','Falling 39',3900,273.0,0.7,'💎','fall','cinematic','epic',true),
('fall-40','شهاب 40','Falling 40',4000,280.0,0.7,'👑','fall','cinematic','epic',true),
('fall-41','شهاب 41','Falling 41',4100,287.0,0.7,'🌠','fall','cinematic','epic',true),
('fall-42','شهاب 42','Falling 42',4200,294.0,0.7,'☄️','fall','cinematic','epic',true),
('fall-43','شهاب 43','Falling 43',4300,301.0,0.7,'🌟','fall','cinematic','epic',true),
('fall-44','شهاب 44','Falling 44',4400,308.0,0.7,'✨','fall','cinematic','epic',true),
('fall-45','شهاب 45','Falling 45',4500,315.0,0.7,'💫','fall','cinematic','epic',true),
('fall-46','شهاب 46','Falling 46',4600,322.0,0.7,'🌙','fall','cinematic','epic',true),
('fall-47','شهاب 47','Falling 47',4700,329.0,0.7,'🔥','fall','cinematic','epic',true),
('fall-48','شهاب 48','Falling 48',4800,336.0,0.7,'⚡','fall','cinematic','epic',true),
('fall-49','شهاب 49','Falling 49',4900,343.0,0.7,'💎','fall','cinematic','epic',true),
('fall-50','شهاب 50','Falling 50',5000,350.0,0.7,'👑','fall','cinematic','epic',true),
('td-01','أسطورة ثلاثية 1','3D Legend 1',1000,70.0,0.7,'🦁','3d','3d','epic',true),
('td-02','أسطورة ثلاثية 2','3D Legend 2',2000,140.0,0.7,'🐯','3d','3d','epic',true),
('td-03','أسطورة ثلاثية 3','3D Legend 3',3000,210.0,0.7,'🦒','3d','3d','epic',true),
('td-04','أسطورة ثلاثية 4','3D Legend 4',4000,280.0,0.7,'🐋','3d','3d','epic',true),
('td-05','أسطورة ثلاثية 5','3D Legend 5',5000,350.0,0.7,'🦅','3d','3d','epic',true),
('td-06','أسطورة ثلاثية 6','3D Legend 6',6000,420.0,0.7,'🦖','3d','3d','epic',true),
('td-07','أسطورة ثلاثية 7','3D Legend 7',7000,490.0,0.7,'🦕','3d','3d','epic',true),
('td-08','أسطورة ثلاثية 8','3D Legend 8',8000,560.0,0.7,'🐉','3d','3d','epic',true),
('td-09','أسطورة ثلاثية 9','3D Legend 9',9000,630.0,0.7,'🦄','3d','3d','epic',true),
('td-10','أسطورة ثلاثية 10','3D Legend 10',10000,700.0,0.7,'🐺','3d','3d','epic',true),
('td-11','أسطورة ثلاثية 11','3D Legend 11',11000,770.0,0.7,'🦁','3d','3d','epic',true),
('td-12','أسطورة ثلاثية 12','3D Legend 12',12000,840.0,0.7,'🐯','3d','3d','epic',true),
('td-13','أسطورة ثلاثية 13','3D Legend 13',13000,910.0,0.7,'🦒','3d','3d','epic',true),
('td-14','أسطورة ثلاثية 14','3D Legend 14',14000,980.0,0.7,'🐋','3d','3d','epic',true),
('td-15','أسطورة ثلاثية 15','3D Legend 15',15000,1050.0,0.7,'🦅','3d','3d','epic',true),
('td-16','أسطورة ثلاثية 16','3D Legend 16',16000,1120.0,0.7,'🦖','3d','3d','epic',true),
('td-17','أسطورة ثلاثية 17','3D Legend 17',17000,1190.0,0.7,'🦕','3d','3d','epic',true),
('td-18','أسطورة ثلاثية 18','3D Legend 18',18000,1260.0,0.7,'🐉','3d','3d','epic',true),
('td-19','أسطورة ثلاثية 19','3D Legend 19',19000,1330.0,0.7,'🦄','3d','3d','epic',true),
('td-20','أسطورة ثلاثية 20','3D Legend 20',20000,1400.0,0.7,'🐺','3d','3d','epic',true),
('td-21','أسطورة ثلاثية 21','3D Legend 21',21000,1470.0,0.7,'🦁','3d','3d','epic',true),
('td-22','أسطورة ثلاثية 22','3D Legend 22',22000,1540.0,0.7,'🐯','3d','3d','epic',true),
('td-23','أسطورة ثلاثية 23','3D Legend 23',23000,1610.0,0.7,'🦒','3d','3d','epic',true),
('td-24','أسطورة ثلاثية 24','3D Legend 24',24000,1680.0,0.7,'🐋','3d','3d','epic',true),
('td-25','أسطورة ثلاثية 25','3D Legend 25',25000,1750.0,0.7,'🦅','3d','3d','epic',true),
('td-26','أسطورة ثلاثية 26','3D Legend 26',26000,1820.0,0.7,'🦖','3d','3d','epic',true),
('td-27','أسطورة ثلاثية 27','3D Legend 27',27000,1890.0,0.7,'🦕','3d','3d','epic',true),
('td-28','أسطورة ثلاثية 28','3D Legend 28',28000,1960.0,0.7,'🐉','3d','3d','epic',true),
('td-29','أسطورة ثلاثية 29','3D Legend 29',29000,2030.0,0.7,'🦄','3d','3d','epic',true),
('td-30','أسطورة ثلاثية 30','3D Legend 30',30000,2100.0,0.7,'🐺','3d','3d','epic',true),
('td-31','أسطورة ثلاثية 31','3D Legend 31',31000,2170.0,0.7,'🦁','3d','3d','epic',true),
('td-32','أسطورة ثلاثية 32','3D Legend 32',32000,2240.0,0.7,'🐯','3d','3d','epic',true),
('td-33','أسطورة ثلاثية 33','3D Legend 33',33000,2310.0,0.7,'🦒','3d','3d','epic',true),
('td-34','أسطورة ثلاثية 34','3D Legend 34',34000,2380.0,0.7,'🐋','3d','3d','epic',true),
('td-35','أسطورة ثلاثية 35','3D Legend 35',35000,2450.0,0.7,'🦅','3d','3d','epic',true),
('td-36','أسطورة ثلاثية 36','3D Legend 36',36000,2520.0,0.7,'🦖','3d','3d','epic',true),
('td-37','أسطورة ثلاثية 37','3D Legend 37',37000,2590.0,0.7,'🦕','3d','3d','epic',true),
('td-38','أسطورة ثلاثية 38','3D Legend 38',38000,2660.0,0.7,'🐉','3d','3d','epic',true),
('td-39','أسطورة ثلاثية 39','3D Legend 39',39000,2730.0,0.7,'🦄','3d','3d','epic',true),
('td-40','أسطورة ثلاثية 40','3D Legend 40',40000,2800.0,0.7,'🐺','3d','3d','epic',true),
('td-41','أسطورة ثلاثية 41','3D Legend 41',41000,2870.0,0.7,'🦁','3d','3d','epic',true),
('td-42','أسطورة ثلاثية 42','3D Legend 42',42000,2940.0,0.7,'🐯','3d','3d','epic',true),
('td-43','أسطورة ثلاثية 43','3D Legend 43',43000,3010.0,0.7,'🦒','3d','3d','epic',true),
('td-44','أسطورة ثلاثية 44','3D Legend 44',44000,3080.0,0.7,'🐋','3d','3d','epic',true),
('td-45','أسطورة ثلاثية 45','3D Legend 45',45000,3150.0,0.7,'🦅','3d','3d','epic',true),
('td-46','أسطورة ثلاثية 46','3D Legend 46',46000,3220.0,0.7,'🦖','3d','3d','epic',true),
('td-47','أسطورة ثلاثية 47','3D Legend 47',47000,3290.0,0.7,'🦕','3d','3d','epic',true),
('td-48','أسطورة ثلاثية 48','3D Legend 48',48000,3360.0,0.7,'🐉','3d','3d','epic',true),
('td-49','أسطورة ثلاثية 49','3D Legend 49',49000,3430.0,0.7,'🦄','3d','3d','epic',true),
('td-50','أسطورة ثلاثية 50','3D Legend 50',50000,3500.0,0.7,'🐺','3d','3d','epic',true)
on conflict(slug) do nothing;

create or replace function public.handle_new_user() returns trigger language plpgsql security definer as $$
begin insert into profiles(id,display_name) values(new.id,coalesce(new.raw_user_meta_data->>'full_name',split_part(new.email,'@',1))); return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create or replace function public.approve_coin_purchase(p_purchase_id uuid) returns void language plpgsql security definer as $$
declare v_user uuid; v_coins numeric;
begin select user_id,coins into v_user,v_coins from coin_purchases where id=p_purchase_id and status='pending' for update;
if v_user is null then raise exception 'الطلب غير موجود'; end if;
update profiles set paid_coins=paid_coins+v_coins where id=v_user;
update coin_purchases set status='approved' where id=p_purchase_id;
insert into admin_audit(actor,action,target,details) values('system','approve_coin_purchase',p_purchase_id::text,json_build_object('coins',v_coins));
end; $$;

create or replace function public.send_economy_gift(p_stream_id uuid,p_gift_slug text,p_coins numeric)
returns json language plpgsql security definer as $$
declare v_sender uuid:=auth.uid(); v_receiver uuid; v_gift gifts%rowtype; v_paid numeric; v_bonus numeric; v_earn numeric;
begin
if v_sender is null then raise exception 'يجب تسجيل الدخول'; end if;
select user_id into v_receiver from streams where id=p_stream_id and status='live';
if v_receiver is null then raise exception 'البث غير موجود أو انتهى'; end if;
if v_receiver=v_sender then raise exception 'لا يمكنك إرسال هدية لنفسك'; end if;
select * into v_gift from gifts where slug=p_gift_slug and active=true;
if v_gift is null then raise exception 'الهدية غير متاحة'; end if;
if p_coins is null or p_coins<v_gift.coin_price then raise exception 'عدد العملات غير كافٍ'; end if;
select paid_coins,bonus_coins into v_paid,v_bonus from profiles where id=v_sender for update;
if coalesce(v_paid,0)+coalesce(v_bonus,0)<p_coins then raise exception 'رصيد العملات غير كافٍ'; end if;
v_paid:=least(coalesce(v_paid,0),p_coins); v_bonus:=p_coins-v_paid;
v_earn:=v_paid*v_gift.creator_ratio;
update profiles set paid_coins=paid_coins-v_paid,bonus_coins=bonus_coins-v_bonus where id=v_sender;
update profiles set earnings=earnings+v_earn where id=v_receiver;
insert into gift_events(stream_id,sender_id,receiver_id,gift_id,coins_spent,paid_coins_used,bonus_coins_used,earnings_added)
values(p_stream_id,v_sender,v_receiver,v_gift.id,p_coins,v_paid,v_bonus,v_earn);
return json_build_object('ok',true,'creator_earnings',v_earn,'paid_used',v_paid,'bonus_used',v_bonus);
end; $$;

grant execute on function public.approve_coin_purchase(uuid) to authenticated;
grant execute on function public.send_economy_gift(uuid,text,numeric) to authenticated;

alter table profiles enable row level security;
alter table videos enable row level security;
alter table streams enable row level security;
alter table gifts enable row level security;
alter table gift_events enable row level security;
alter table coin_purchases enable row level security;
alter table payout_requests enable row level security;
alter table admin_audit enable row level security;

create policy "read approved videos" on videos for select using (status='approved');
create policy "insert own video" on videos for insert with check (auth.uid()=user_id);
create policy "read own video" on videos for select using (auth.uid()=user_id or status='approved');
create policy "read own profile" on profiles for select using (auth.uid()=id);
create policy "update own profile" on profiles for update using (auth.uid()=id);
create policy "read gifts" on gifts for select using (active=true);
create policy "read gift events" on gift_events for select using (true);
create policy "create stream" on streams for insert with check (auth.uid()=user_id);
create policy "read streams" on streams for select using (true);
create policy "create purchase" on coin_purchases for insert with check (auth.uid()=user_id);
create policy "read own purchase" on coin_purchases for select using (auth.uid()=user_id);
create policy "create payout" on payout_requests for insert with check (auth.uid()=user_id);
create policy "read own payout" on payout_requests for select using (auth.uid()=user_id);
