-- ===== security-phase1c.sql =====

-- 1) إغلاق approve_coin_purchase احتياطًا
revoke execute on function public.approve_coin_purchase(uuid)
from anon, authenticated, public;

-- request_payout: إنشاؤها أو تحديثها بنفس التعريف الآمن
create or replace function public.request_payout(
  p_amount_egp numeric,
  p_phone text
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_balance numeric;
  v_id uuid;
begin
  if v_user is null then
    raise exception 'يجب تسجيل الدخول';
  end if;

  if p_amount_egp is null or p_amount_egp < 50 then
    raise exception 'الحد الأدنى للسحب 50 جنيه';
  end if;

  if p_phone is null or length(p_phone) < 10 then
    raise exception 'رقم فودافون كاش غير صحيح';
  end if;

  select earnings
  into v_balance
  from public.profiles
  where id = v_user
  for update;

  if v_balance is null or v_balance < p_amount_egp then
    raise exception 'رصيد الأرباح غير كافٍ';
  end if;

  update public.profiles
  set earnings = earnings - p_amount_egp
  where id = v_user;

  insert into public.payout_requests(user_id, amount_egp, phone, status)
  values (v_user, p_amount_egp, p_phone, 'pending')
  returning id into v_id;

  return v_id;
end;
$$;

revoke execute on function public.request_payout(numeric, text)
from anon, public;
grant execute on function public.request_payout(numeric, text)
to authenticated;

-- 2) منع المستخدم من نشر فيديو بحالة غير pending
drop policy if exists "insert own video" on public.videos;
drop policy if exists "create pending video" on public.videos;

create policy "create pending video"
on public.videos
for insert to authenticated
with check (
  auth.uid() = user_id
  and status = 'pending'
);

-- منع المستخدم من تعديل views و likes
revoke update on table public.videos from authenticated, anon;
grant update (title) on table public.videos to authenticated;

-- منع إدخال views أو likes بقيم غير الصفر
create or replace function public.enforce_zero_video_counters()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.views is distinct from 0 or new.likes is distinct from 0 then
    raise exception 'لا يمكن إدخال قيم views أو likes';
  end if;
  return new;
end;
$$;

drop trigger if exists enforce_zero_video_counters_trigger on public.videos;
create trigger enforce_zero_video_counters_trigger
before insert on public.videos
for each row
execute function public.enforce_zero_video_counters();

-- 3) تغذية الهدايا العامة للبث
create table if not exists public.stream_gift_feed (
  id uuid primary key default gen_random_uuid(),
  stream_id uuid not null,
  gift_id uuid references public.gifts(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.stream_gift_feed enable row level security;

drop policy if exists "public read stream gift feed" on public.stream_gift_feed;
create policy "public read stream gift feed"
on public.stream_gift_feed
for select
using (true);

-- لا سياسة insert للمستخدمين: التغذية تتم من send_economy_gift فقط
revoke insert on table public.stream_gift_feed from anon, authenticated;

-- تعديل send_economy_gift لتغذية stream_gift_feed
create or replace function public.send_economy_gift(
  p_stream_id uuid,
  p_gift_slug text,
  p_coins numeric
)
returns json
language plpgsql
security definer
set search_path = public
as $$
declare
  v_sender uuid := auth.uid();
  v_receiver uuid;
  v_gift public.gifts%rowtype;
  v_paid numeric;
  v_bonus numeric;
  v_total numeric;
  v_earn numeric;
  v_event_id uuid;
begin
  if v_sender is null then
    raise exception 'يجب تسجيل الدخول';
  end if;

  select user_id into v_receiver
  from public.streams
  where id = p_stream_id and status = 'live';

  if v_receiver is null then
    raise exception 'البث غير موجود أو انتهى';
  end if;

  if v_receiver = v_sender then
    raise exception 'لا يمكنك إرسال هدية لنفسك';
  end if;

  select * into v_gift
  from public.gifts
  where slug = p_gift_slug and active = true;

  if v_gift is null then
    raise exception 'الهدية غير متاحة';
  end if;

  v_total := v_gift.coin_price;

  select paid_coins, bonus_coins
  into v_paid, v_bonus
  from public.profiles
  where id = v_sender
  for update;

  if coalesce(v_paid,0) + coalesce(v_bonus,0) < v_total then
    raise exception 'رصيد العملات غير كافٍ';
  end if;

  v_paid := least(coalesce(v_paid,0), v_total);
  v_bonus := v_total - v_paid;
  v_earn := v_paid * v_gift.creator_ratio;

  update public.profiles
  set paid_coins = paid_coins - v_paid,
      bonus_coins = bonus_coins - v_bonus
  where id = v_sender;

  update public.profiles
  set earnings = earnings + v_earn
  where id = v_receiver;

  insert into public.gift_events(
    stream_id, sender_id, receiver_id, gift_id,
    coins_spent, paid_coins_used, bonus_coins_used, earnings_added
  )
  values (
    p_stream_id, v_sender, v_receiver, v_gift.id,
    v_total, v_paid, v_bonus, v_earn
  )
  returning id into v_event_id;

  insert into public.stream_gift_feed(stream_id, gift_id)
  values (p_stream_id, v_gift.id);

  return json_build_object(
    'ok', true,
    'event_id', v_event_id,
    'coins_spent', v_total,
    'paid_coins_used', v_paid,
    'bonus_coins_used', v_bonus,
    'creator_earnings', v_earn
  );
end;
$$;

revoke execute on function public.send_economy_gift(uuid, text, numeric)
from anon;
grant execute on function public.send_economy_gift(uuid, text, numeric)
to authenticated;

-- تفعيل Realtime للجدول
alter publication supabase_realtime add table public.stream_gift_feed;
alter table public.gifts add column if not exists duration_ms int default 5000;
