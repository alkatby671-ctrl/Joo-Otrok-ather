-- المرحلة 2: الفيد + التفاعل (بعد phase1 ثم 1b ثم 1c)
create table if not exists public.video_likes(user_id uuid references auth.users on delete cascade, video_id uuid references public.videos on delete cascade, primary key(user_id,video_id));
create table if not exists public.video_saves(user_id uuid references auth.users on delete cascade, video_id uuid references public.videos on delete cascade, primary key(user_id,video_id));
create table if not exists public.video_views(user_id uuid references auth.users on delete cascade, video_id uuid references public.videos on delete cascade, primary key(user_id,video_id));
create table if not exists public.follows(follower_id uuid references auth.users on delete cascade, followee_id uuid references auth.users on delete cascade, primary key(follower_id,followee_id), check(follower_id<>followee_id));
create table if not exists public.comments(id uuid primary key default gen_random_uuid(), video_id uuid references public.videos on delete cascade, user_id uuid references auth.users on delete cascade, body text not null check(length(body) between 1 and 300), created_at timestamptz default now());
alter table public.videos add column if not exists comments bigint default 0;
create index if not exists videos_feed_idx on public.videos(status, created_at desc);
alter table public.video_likes enable row level security; alter table public.video_saves enable row level security;
alter table public.video_views enable row level security; alter table public.follows enable row level security; alter table public.comments enable row level security;
create policy "own likes" on public.video_likes for all to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);
create policy "own saves" on public.video_saves for all to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);
create policy "own follows" on public.follows for all to authenticated using(auth.uid()=follower_id) with check(auth.uid()=follower_id);
create policy "read comments" on public.comments for select using(true);
create policy "add comment" on public.comments for insert to authenticated with check(auth.uid()=user_id);
create policy "delete own comment" on public.comments for delete to authenticated using(auth.uid()=user_id);
create or replace function public.bump_counter() returns trigger language plpgsql security definer set search_path=public as $$
declare d int := case when tg_op='INSERT' then 1 else -1 end; v uuid := coalesce(new.video_id, old.video_id);
begin
 if tg_table_name='video_likes' then update videos set likes=greatest(likes+d,0) where id=v;
 else update videos set comments=greatest(comments+d,0) where id=v; end if; return null; end; $$;
create trigger t_likes after insert or delete on public.video_likes for each row execute function public.bump_counter();
create trigger t_comments after insert or delete on public.comments for each row execute function public.bump_counter();
create or replace function public.register_view(p_video uuid) returns void language plpgsql security definer set search_path=public as $$
begin if auth.uid() is null then return; end if;
 insert into video_views values(auth.uid(),p_video) on conflict do nothing;
 if found then update videos set views=views+1 where id=p_video and status='approved'; end if; end; $$;
revoke execute on function public.register_view(uuid) from anon, public; grant execute on function public.register_view(uuid) to authenticated;
create or replace view public.public_profiles as select id, username, display_name, avatar_url from public.profiles;
grant select on public.public_profiles to anon, authenticated;
create or replace function public.get_feed(p_mode text default 'foryou', p_limit int default 8, p_offset int default 0)
returns table(id uuid,title text,video_url text,user_id uuid,author text,avatar_url text,views bigint,likes bigint,comments bigint,liked boolean,saved boolean,followed boolean)
language sql stable security invoker set search_path=public as $$
 select v.id,v.title,v.video_url,v.user_id,coalesce(p.display_name,p.username,'مبدع'),p.avatar_url,v.views,v.likes,v.comments,
  exists(select 1 from video_likes l where l.video_id=v.id and l.user_id=auth.uid()),
  exists(select 1 from video_saves s where s.video_id=v.id and s.user_id=auth.uid()),
  exists(select 1 from follows f where f.followee_id=v.user_id and f.follower_id=auth.uid())
 from videos v left join public_profiles p on p.id=v.user_id
 where v.status='approved' and (p_mode<>'following' or exists(select 1 from follows f where f.followee_id=v.user_id and f.follower_id=auth.uid()))
 order by (v.likes*3+v.comments*5+v.views*0.5+10)/power(extract(epoch from now()-v.created_at)/3600+2,1.3) desc, v.id
 limit least(p_limit,20) offset greatest(p_offset,0) $$;
grant execute on function public.get_feed(text,int,int) to anon, authenticated;
