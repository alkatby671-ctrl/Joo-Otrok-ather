"use client";
import { useEffect,useState } from "react";
import { supabase } from "../lib/supabase";
import { playGiftSound } from "./SoundEngine";
export default function GiftBar({streamId}){
 const[g,setG]=useState([]);const[c,setC]=useState({paid_coins:0,bonus_coins:0});const[m,setM]=useState("");
 useEffect(()=>{(async()=>{const x=await supabase.from("gifts").select("*").eq("active",true).order("coin_price");setG(x.data||[]);
 const{data:{user}}=await supabase.auth.getUser();if(!user)return;const p=await supabase.from("profiles").select("paid_coins,bonus_coins").eq("id",user.id).single();setC(p.data||c)})()},[]);
 async function send(x){playGiftSound(x.kind==="scary"?"scary":"epic");
  const{error}=await supabase.rpc("send_economy_gift",{p_stream_id:streamId,p_gift_slug:x.slug,p_coins:x.coin_price});
  setM(error?error.message:`تم إرسال ${x.name_ar}`);}
 return(<div className="card"><h3>الهدايا</h3><p>مدفوعة: {(c.paid_coins||0).toLocaleString()} — ترويجية: {(c.bonus_coins||0).toLocaleString()}</p>
 <div style={{display:"flex",flexWrap:"wrap",gap:8}}>{g.slice(0,24).map(x=>(<button key={x.id} className="btn" onClick={()=>send(x)}>{x.emoji} {x.name_ar} — {x.coin_price}</button>))}</div><p>{m}</p></div>);
}