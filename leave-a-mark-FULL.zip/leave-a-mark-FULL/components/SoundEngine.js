export function playGiftSound(kind="epic"){
 try{
  const ctx=new (window.AudioContext||window.webkitAudioContext)();
  const o=ctx.createOscillator(),g=ctx.createGain();
  o.type=kind==="scary"?"sawtooth":"sine";
  o.frequency.setValueAtTime(kind==="scary"?90:220,ctx.currentTime);
  o.frequency.exponentialRampToValueAtTime(kind==="scary"?35:880,ctx.currentTime+.8);
  g.gain.setValueAtTime(.25,ctx.currentTime);
  g.gain.exponentialRampToValueAtTime(.001,ctx.currentTime+1.2);
  o.connect(g).connect(ctx.destination);o.start();o.stop(ctx.currentTime+1.2);
 }catch(e){}
}