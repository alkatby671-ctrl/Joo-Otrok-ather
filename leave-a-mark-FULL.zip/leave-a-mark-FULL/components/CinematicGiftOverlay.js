"use client";

import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import { playGiftSound } from "./SoundEngine";

export default function CinematicGiftOverlay({ streamId }) {
  const [active, setActive] = useState([]);

  useEffect(() => {
    if (!streamId) return;

    const channel = supabase
      .channel(`stream-gift-feed-${streamId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "stream_gift_feed",
          filter: `stream_id=eq.${streamId}`
        },
        async (payload) => {
          const { data: gift, error } = await supabase
            .from("gifts")
            .select("slug,name_ar,emoji,animation,kind,duration_ms")
            .eq("id", payload.new.gift_id)
            .single();

          if (error || !gift) return;

          const item = {
            id: payload.new.id,
            slug: gift.slug,
            name: gift.name_ar,
            icon: gift.emoji,
            animation: gift.animation,
            kind: gift.kind,
            duration: gift.duration_ms || 5000
          };

          setActive((prev) => [...prev, item]);
          playGiftSound(item.kind === "scary" ? "scary" : "epic");

          setTimeout(() => {
            setActive((prev) => prev.filter((x) => x.id !== item.id));
          }, item.duration);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [streamId]);

  return (
    <>
      {active.map((item) => (
        <div className="cinematic-overlay" key={item.id}>
          <div className="cinematic-center">
            <div className={`gift-icon anim-${item.animation}`}>
              {item.icon}
            </div>
          </div>
          <div className="gift-title">{item.name}</div>
        </div>
      ))}
    </>
  );
}
