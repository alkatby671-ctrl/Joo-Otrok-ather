"use client";
import { useState } from "react";
import { supabase } from "../lib/supabase";
export default function Upload(){
 const[file,setFile]=useState(null);const[title,setTitle]=useState("");const[msg,setMsg]=useState("");
 async function up(){
  try{
   const{data:{user}}=await supabase.auth.getUser();if(!user)return setMsg("سجّل الدخول");
   const path=`${user.id}/${Date.now()}-${file.name}`;
   const{error:e1}=await supabase.storage.from("videos").upload(path,file);if(e1)throw e1;
   const{data:{publicUrl}}=supabase.storage.from("videos").getPublicUrl(path);
   const{error:e2}=await supabase.from("videos").insert({user_id:user.id,title,video_url:publicUrl,status:"pending"});if(e2)throw e2;
   setMsg("تم الرفع، بانتظار المراجعة.");
  }catch(e){setMsg(e.message)}
 }
 return(<main style={{maxWidth:520,margin:"40px auto",padding:20}}><div className="card">
  <h2>رفع فيديو</h2><input className="input" placeholder="العنوان" value={title} onChange={e=>setTitle(e.target.value)}/>
  <input className="input" type="file" accept="video/*" onChange={e=>setFile(e.target.files[0])}/>
  <button className="btn" onClick={up}>نشر</button><p>{msg}</p></div></main>);
}