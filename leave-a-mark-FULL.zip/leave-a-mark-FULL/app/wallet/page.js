"use client";
import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";

export default function Wallet() {
  const [wallet, setWallet] = useState({
    paid_coins: 0,
    bonus_coins: 0,
    earnings: 0
  });
  const [amount, setAmount] = useState("");
  const [phone, setPhone] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function load() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from("profiles")
      .select("paid_coins,bonus_coins,earnings")
      .eq("id", user.id)
      .single();

    setWallet(data || { paid_coins: 0, bonus_coins: 0, earnings: 0 });
  }

  useEffect(() => {
    load();
  }, []);

  async function requestPayout() {
    setBusy(true);
    setMessage("");

    const { error } = await supabase.rpc("request_payout", {
      p_amount_egp: Number(amount),
      p_phone: phone
    });

    setBusy(false);

    if (error) {
      setMessage(error.message);
      return;
    }

    setMessage("تم إنشاء طلب السحب، وبانتظار مراجعة الإدارة.");
    setAmount("");
    setPhone("");
    await load();
  }

  return (
    <main style={{ maxWidth: 520, margin: "40px auto", padding: 20 }}>
      <div className="card">
        <h2>المحفظة</h2>
        <p>عملات مدفوعة: {(wallet.paid_coins || 0).toLocaleString()}</p>
        <p>عملات ترويجية: {(wallet.bonus_coins || 0).toLocaleString()}</p>
        <p>أرباح قابلة للسحب: {wallet.earnings || 0} جنيه</p>

        <hr style={{ borderColor: "#1c2036" }} />

        <h3>طلب سحب</h3>
        <input
          className="input"
          type="number"
          min="50"
          placeholder="المبلغ بالجنيه"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <input
          className="input"
          placeholder="رقم فودافون كاش"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
        />
        <button className="btn" onClick={requestPayout} disabled={busy}>
          {busy ? "جارٍ الإرسال..." : "طلب سحب"}
        </button>

        <p>{message}</p>
        <p>الحد الأدنى للسحب: 50 جنيه.</p>
      </div>
    </main>
  );
}
