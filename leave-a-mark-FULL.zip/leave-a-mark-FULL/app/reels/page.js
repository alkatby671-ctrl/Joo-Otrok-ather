"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { supabase } from "../../lib/supabase";
import "./reels.css";

const PAGE = 8;

function Comments({ id, me, onClose, onAdded }) {
  const [list, setList] = useState([]);
  const [text, setText] = useState("");
  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("comments").select("id,body,user_id").eq("video_id", id).order("created_at", { ascending: false }).limit(50);
      const ids = [...new Set((data || []).map((c) => c.user_id))];
      const { data: ps } = ids.length ? await supabase.from("public_profiles").select("id,display_name,username").in("id", ids) : { data: [] };
      const m = Object.fromEntries((ps || []).map((p) => [p.id, p.display_name || p.username]));
      setList((data || []).map((c) => ({ ...c, name: m[c.user_id] || "مستخدم" })));
    })();
  }, [id]);
  async function send(e) {
    e.preventDefault();
    const body = text.trim();
    if (!body || !me) return;
    const { error } = await supabase.from("comments").insert({ video_id: id, user_id: me.id, body });
    if (error) return alert(error.message);
    setList((l) => [{ id: Date.now(), body, name: "أنت" }, ...l]);
    setText("");
    onAdded();
  }
  return (
    <div className="sheet">
      <header><span>التعليقات</span><button onClick={onClose} aria-label="إغلاق">✕</button></header>
      <ul>{list.length ? list.map((c) => <li key={c.id}><b>{c.name}</b>{c.body}</li>) : <li>لا توجد تعليقات بعد. ابدأ أنت.</li>}</ul>
      {me ? <form onSubmit={send}><input value={text} maxLength={300} onChange={(e) => setText(e.target.value)} placeholder="اكتب تعليقًا" /><button>نشر</button></form> : <Link href="/login">سجّل الدخول للتعليق</Link>}
    </div>
  );
}

export default function Reels() {
  const [mode, setMode] = useState("foryou");
  const [items, setItems] = useState([]);
  const [cur, setCur] = useState(0);
  const [muted, setMuted] = useState(true);
  const [me, setMe] = useState(null);
  const [open, setOpen] = useState(null);
  const [toast, setToast] = useState("");
  const [ready, setReady] = useState(false);
  const busy = useRef(false), done = useRef(false), offset = useRef(0), box = useRef(null), vids = useRef({});
  const say = (t) => { setToast(t); setTimeout(() => setToast(""), 2200); };

  const load = useCallback(async (reset = false) => {
    if (busy.current) return;
    if (reset) { offset.current = 0; done.current = false; }
    if (done.current) return;
    busy.current = true;
    const { data, error } = await supabase.rpc("get_feed", { p_mode: mode, p_limit: PAGE, p_offset: offset.current });
    busy.current = false;
    setReady(true);
    if (error) return say(error.message);
    offset.current += data.length;
    if (data.length < PAGE) done.current = true;
    setItems((p) => (reset ? data : [...p, ...data]));
  }, [mode]);

  useEffect(() => { supabase.auth.getUser().then(({ data }) => setMe(data.user)); }, []);
  useEffect(() => { setCur(0); box.current?.scrollTo(0, 0); load(true); }, [load]);

  useEffect(() => {
    if (!box.current) return;
    const io = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && setCur(Number(e.target.dataset.i))), { root: box.current, threshold: 0.7 });
    box.current.querySelectorAll(".reel").forEach((n) => io.observe(n));
    return () => io.disconnect();
  }, [items.length]);

  useEffect(() => {
    Object.entries(vids.current).forEach(([i, v]) => {
      if (!v) return;
      if (Number(i) === cur) { v.muted = muted; v.play().catch(() => {}); } else { v.pause(); v.currentTime = 0; }
    });
    if (items.length && cur >= items.length - 3) load();
    const it = items[cur];
    if (!it || !me) return;
    const t = setTimeout(() => supabase.rpc("register_view", { p_video: it.id }), 3000);
    return () => clearTimeout(t);
  }, [cur, muted, items, me, load]);

  const patch = (match, f) => setItems((p) => p.map((x) => (match(x) ? { ...x, ...f(x) } : x)));
  const guest = () => { if (!me) { say("سجّل الدخول أولًا"); return true; } return false; };

  async function toggle(v, table, key, extra) {
    if (guest()) return;
    const on = !v[key];
    patch((x) => x.id === v.id, (x) => ({ [key]: on, ...(extra ? extra(x, on) : {}) }));
    const q = supabase.from(table);
    const { error } = on ? await q.insert({ user_id: me.id, video_id: v.id }) : await q.delete().eq("video_id", v.id).eq("user_id", me.id);
    if (error) patch((x) => x.id === v.id, (x) => ({ [key]: !on, ...(extra ? extra(x, !on) : {}) }));
  }
  const like = (v) => toggle(v, "video_likes", "liked", (x, on) => ({ likes: x.likes + (on ? 1 : -1) }));
  const save = (v) => toggle(v, "video_saves", "saved");

  async function follow(v) {
    if (guest() || v.user_id === me.id) return;
    const on = !v.followed;
    patch((x) => x.user_id === v.user_id, () => ({ followed: on }));
    const q = supabase.from("follows");
    const { error } = on ? await q.insert({ follower_id: me.id, followee_id: v.user_id }) : await q.delete().eq("follower_id", me.id).eq("followee_id", v.user_id);
    if (error) patch((x) => x.user_id === v.user_id, () => ({ followed: !on }));
  }
  async function share(v) {
    const url = location.origin + "/reels";
    try { if (navigator.share) await navigator.share({ title: v.title || "اترك أثر", url }); else { await navigator.clipboard.writeText(url); say("تم نسخ الرابط"); } } catch {}
  }

  return (
    <main className="feed-wrap">
      <header className="tabs">
        <Link href="/upload" className="plus" aria-label="رفع فيديو">＋</Link>
        <button className={mode === "following" ? "on" : ""} onClick={() => setMode("following")}>متابَعين</button>
        <button className={mode === "foryou" ? "on" : ""} onClick={() => setMode("foryou")}>لك</button>
        <button className="snd" onClick={() => setMuted((m) => !m)} aria-label="الصوت">{muted ? "🔇" : "🔊"}</button>
      </header>
      <div className="feed" ref={box}>
        {ready && !items.length && (
          <div className="empty">
            <b>{mode === "following" ? "لا يوجد فيديوهات من متابَعيك" : "لا توجد فيديوهات بعد"}</b>
            {mode === "following" ? <span>تابع مبدعين من تبويب «لك»</span> : <Link href="/upload">ارفع أول فيديو</Link>}
          </div>
        )}
        {items.map((v, i) => {
          const near = Math.abs(i - cur) <= 1;
          return (
            <section className="reel" data-i={i} key={v.id}>
              <video ref={(el) => { vids.current[i] = el; }} src={near ? v.video_url : undefined} preload={near ? "auto" : "none"} loop playsInline muted={muted}
                onClick={(e) => { const el = e.currentTarget; el.paused ? el.play() : el.pause(); }} onDoubleClick={() => !v.liked && like(v)} />
              <div className="side">
                <button className={v.liked ? "on" : ""} onClick={() => like(v)} aria-label="إعجاب">♥<small>{v.likes}</small></button>
                <button onClick={() => setOpen(v.id)} aria-label="تعليقات">💬<small>{v.comments}</small></button>
                <button className={v.saved ? "on" : ""} onClick={() => save(v)} aria-label="حفظ">★<small>حفظ</small></button>
                <button onClick={() => share(v)} aria-label="مشاركة">↗<small>مشاركة</small></button>
              </div>
              <div className="info">
                <b>@{v.author}</b>
                {me?.id !== v.user_id && <button className={"fol" + (v.followed ? " on" : "")} onClick={() => follow(v)}>{v.followed ? "تتابعه" : "متابعة"}</button>}
                {v.title && <p>{v.title}</p>}
              </div>
            </section>
          );
        })}
      </div>
      {open && <Comments id={open} me={me} onClose={() => setOpen(null)} onAdded={() => patch((x) => x.id === open, (x) => ({ comments: x.comments + 1 }))} />}
      {toast && <div className="toast">{toast}</div>}
    </main>
  );
}
