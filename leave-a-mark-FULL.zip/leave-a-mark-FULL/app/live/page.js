"use client";
import { useState } from "react";
import { supabase } from "../lib/supabase";
import GiftBar from "../components/GiftBar";
import CinematicGiftOverlay from "../components/CinematicGiftOverlay";
export default function Live(){
 const[t,setT]=useState("");const[id,setID]=useState("");const[s,setS]=useState("");
 async function start(){const{data:{user}}=await supabase.auth.getUser();if(!user)return setS("سجّل الدخول");
 const{data,error}=await supabase.from("streams").insert({user_id:user.id,title:t,status:"live"}).select("id").single();
 if(error)return setS(error.message);setID(data.id);setS("بدأ البث.");}
 return(<main style={{maxWidth:780,margin:"30px auto",padding:20}}><div className="card">
 <h2>استوديو البث</h2>
 {!id?<>(<input className="input" placeholder="عنوان البث" value={t} onChange={e=>setT(e.target.value)}/><button className="btn" onClick={start}>بدء البث</button>)</>:(
 <><div style={{aspectRatio:"16/9",background:"#000",borderRadius:14,position:"relative",overflow:"hidden"}}><CinematicGiftOverlay streamId={id}/><p style={{position:"absolute",bottom:10,left:12,color:"#fff"}}>منطقة البث الحقيقي</p></div><GiftBar streamId={id}/></>)}
 <p>{s}</p></div></main>);
}