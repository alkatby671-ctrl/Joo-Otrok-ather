import "./globals.css";
import "./gifts.css";
export const metadata={title:"اترك أثر | Leave a Mark"};
export default function RootLayout({children}){return(<html lang="ar" dir="rtl"><body>{children}</body></html>)}