export { default } from "../../components/GiftBar";
