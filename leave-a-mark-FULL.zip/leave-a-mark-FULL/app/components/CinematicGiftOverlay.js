export { default } from "../../components/CinematicGiftOverlay";
