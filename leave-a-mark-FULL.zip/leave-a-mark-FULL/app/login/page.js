"use client";
import { useState } from "react";
import { supabase } from "../lib/supabase";
export default function Login(){
 const [email,setEmail]=useState("");const[password,setPassword]=useState("");const[phone,setPhone]=useState("");const[msg,setMsg]=useState("");
 async function login(){const{error}=await supabase.auth.signInWithPassword({email,password});setMsg(error?error.message:"تم الدخول");}
 async function google(){await supabase.auth.signInWithOAuth({provider:"google",options:{redirectTo:location.origin+"/reels"}});}
 async function otp(){const{error}=await supabase.auth.signInWithOtp({phone});setMsg(error?error.message:"تم إرسال الرمز");}
 return(<main style={{maxWidth:430,margin:"50px auto",padding:20}}>
  <div className="card">
   <h2>دخول اترك أثر</h2>
   <input className="input" placeholder="البريد" value={email} onChange={e=>setEmail(e.target.value)}/>
   <input className="input" type="password" placeholder="كلمة المرور" value={password} onChange={e=>setPassword(e.target.value)}/>
   <button className="btn" onClick={login}>دخول</button>
   <hr style={{borderColor:"#1c2036"}}/>
   <input className="input" placeholder="+2010xxxxxxxx" value={phone} onChange={e=>setPhone(e.target.value)}/>
   <button className="btn" onClick={otp}>دخول برقم الهاتف</button>
   <hr style={{borderColor:"#1c2036"}}/>
   <button className="btn" onClick={google}>المتابعة بجوجل</button>
   <p>{msg}</p>
  </div>
 </main>);
}