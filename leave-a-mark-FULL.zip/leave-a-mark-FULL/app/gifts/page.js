"use client";
import { useEffect,useState } from "react";
import { supabase } from "../lib/supabase";
export default function Gifts(){
 const[g,setG]=useState([]);
 useEffect(()=>{(async()=>{const{data}=await supabase.from("gifts").select("*").eq("active",true).order("coin_price");setG(data||[])})()},[]);
 return(<main style={{padding:20}}><nav className="nav"><strong>معرض الهدايا</strong><a href="/live">البث</a></nav>
 <h1>100 هدية</h1><div className="grid">{g.map(x=>(<div className="card" key={x.id} style={{textAlign:"center"}}>
 <div className={`gift-icon anim-${x.animation}`}>{x.emoji}</div><h3>{x.name_ar}</h3><p>{x.coin_price.toLocaleString()} عملة</p><p>{x.type==="3d"?"3D":"سينمائية"}</p></div>))}</div></main>);
}