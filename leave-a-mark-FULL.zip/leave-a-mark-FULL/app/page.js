import Link from "next/link";
export default function Home(){
 return(<main>
  <nav className="nav"><strong>اترك أثر</strong><Link href="/reels">الريلز</Link><Link href="/live">البث</Link><Link href="/gifts">الهدايا</Link><Link href="/wallet">المحفظة</Link><Link href="/login">دخول</Link></nav>
  <div className="card" style={{margin:24}}>
   <h1>اترك أثر</h1>
   <p>منصة تكنولوجية للفيديو والبث المباشر، بهوية فاخرة وهدايا سينمائية واقتصاد حقيقي للمبدعين.</p>
   <Link className="btn" href="/reels">ابدأ الآن</Link>
  </div>
 </main>);
}